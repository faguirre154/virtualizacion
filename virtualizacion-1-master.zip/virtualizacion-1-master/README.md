# virtualizacion
La documentacion para la platica de virtualizacion
Mi cambio
